webpackJsonp(["authorizations.module"],{

/***/ "../../../../../src/app/views/authorizations/authDto.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AuthorizationDto; });
var AuthorizationDto = /** @class */ (function () {
    function AuthorizationDto() {
    }
    return AuthorizationDto;
}());



/***/ }),

/***/ "../../../../../src/app/views/authorizations/authorizations.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"animated fadeIn\">\n  <div class=\"row\">\n    <div class=\"col-sm-12\">\n      <div class=\"card\">\n        <div class=\"card-header\">\n          <a (click)=\"toggleAccordion()\">Filters</a>\n        </div>\n        <div *ngIf=\"filtersAccordionOpened\">\n          <app-data-table-filters\n            [filters]=\"filters\">\n          </app-data-table-filters>\n        </div>\n      </div>\n    </div>\n  </div>\n  <div class=\"row\" style=\"margin-bottom: 25px;\">\n    <div class=\"col-sm-12\">\n      <app-data-table\n        [pageSize]=\"8\"\n        [columnNames]=\"columnNames\"\n        [getData]=\"getDataFunc\"\n        [select]=\"onSelectFunc\">\n      </app-data-table>\n    </div>\n  </div>\n  <div class=\"row\">\n    <div class=\"col-sm-12\">\n      <button\n        style=\"margin-right: 3px;\"\n        *ngIf=\"selectedAuth\"\n        class=\"pull-right btn btn-primary\"\n        (click)=\"viewUsage()\">\n        View usage\n      </button>\n      <button\n        style=\"margin-right: 3px;\"\n        *ngIf=\"selectedAuth\"\n        class=\"pull-right btn btn-danger\"\n        (click)=\"delete()\">\n        Delete\n      </button>\n      <button\n        style=\"margin-right: 3px;\"\n        class=\"pull-right btn btn-primary\"\n        (click)=\"addNew()\">\n        Add\n      </button>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "../../../../../src/app/views/authorizations/authorizations.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".card-header a {\n  color: #5b06f6;\n  cursor: pointer; }\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/views/authorizations/authorizations.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AuthorizationsComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__authorizations_service__ = __webpack_require__("../../../../../src/app/views/authorizations/authorizations.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_datatable_data_table_service__ = __webpack_require__("../../../../../src/app/shared/datatable/data-table.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__authDto__ = __webpack_require__("../../../../../src/app/views/authorizations/authDto.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_utils_service__ = __webpack_require__("../../../../../src/app/shared/utils.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_ngx_bootstrap__ = __webpack_require__("../../../../ngx-bootstrap/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__create_auth_modal_create_auth_modal_component__ = __webpack_require__("../../../../../src/app/views/authorizations/create-auth-modal/create-auth-modal.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__view_auth_usage_modal_view_auth_usage_modal_component__ = __webpack_require__("../../../../../src/app/views/authorizations/view-auth-usage-modal/view-auth-usage-modal.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var AuthorizationsComponent = /** @class */ (function () {
    function AuthorizationsComponent(authorizationsService, utils, dataTableService, modalService) {
        this.authorizationsService = authorizationsService;
        this.utils = utils;
        this.dataTableService = dataTableService;
        this.modalService = modalService;
        this.columnNames = [
            { name: 'Name' }
        ];
        /**
         * Filters object for data table component
         * @type {any[]}
         */
        this.filters = [
            { label: 'Name', type: 'string', name: 'name', cssClass: 'col-sm-3' }
        ];
        this.filtersAccordionOpened = false;
    }
    AuthorizationsComponent.prototype.ngOnInit = function () {
        // Bind
        this.getDataFunc = this.getData.bind(this);
        this.onSelectFunc = this.onSelect.bind(this);
    };
    /**
     * The service callback
     * @param params
     * @returns {Observable<PagedData<any>>}
     */
    AuthorizationsComponent.prototype.getData = function (params) {
        return this.authorizationsService.getAuthorizationsPaged(params);
    };
    /**
     * Auth. selection handler
     * Copy the selected auth. into a local dto
     * @param {any} selected
     */
    AuthorizationsComponent.prototype.onSelect = function (_a) {
        var selected = _a.selected;
        var selectedAuth = selected[0];
        this.selectedAuth = new __WEBPACK_IMPORTED_MODULE_3__authDto__["a" /* AuthorizationDto */]();
        this.selectedAuth.Id = selectedAuth.id;
        this.selectedAuth.Name = selectedAuth.name;
    };
    /**
     * Open/Close filters accordion
     */
    AuthorizationsComponent.prototype.toggleAccordion = function () {
        this.filtersAccordionOpened = !this.filtersAccordionOpened;
    };
    /**
     * Request deletion for an authorization
     */
    AuthorizationsComponent.prototype.delete = function () {
        var deleteAuthCallback = function () {
            var _this = this;
            this.authorizationsService.delete(this.selectedAuth.Id).subscribe(function () {
                _this.dataTableService.invokeRowDelete();
            }, function (errorResponse) { return _this.utils.handleHttpError(errorResponse); });
        }.bind(this);
        // Call the delete service after confirmation
        this.utils.openConfirmModal("Delete confirmation", "Are you sure to delete the authorization: " + this.selectedAuth.Name + "?", "modal-warning", deleteAuthCallback);
    };
    /**
     * Open a modal to add a new authorization,
     * on submit send the creation command and handle the response
     */
    AuthorizationsComponent.prototype.addNew = function () {
        var _this = this;
        var bsAuthCreationModal = this.modalService.show(__WEBPACK_IMPORTED_MODULE_6__create_auth_modal_create_auth_modal_component__["a" /* CreateAuthModalComponent */]);
        bsAuthCreationModal.content.modalTitle = "New authorization";
        bsAuthCreationModal.content.modalCss = "modal-info";
        bsAuthCreationModal.content.onCreate.subscribe(function (name) {
            var authInsertCommand = {
                Name: name
            };
            _this.authorizationsService.create(authInsertCommand).subscribe(function () {
                bsAuthCreationModal.hide();
                _this.dataTableService.invokeReload();
            }, function (errorResponse) { return _this.utils.handleHttpError(errorResponse); });
        });
    };
    /**
     * Show authorization usage
     */
    AuthorizationsComponent.prototype.viewUsage = function () {
        var bsAuthUsageModal = this.modalService.show(__WEBPACK_IMPORTED_MODULE_7__view_auth_usage_modal_view_auth_usage_modal_component__["a" /* ViewAuthUsageModalComponent */]);
        bsAuthUsageModal.content.authId = this.selectedAuth.Id;
        bsAuthUsageModal.content.modalTitle = "Authorization usage";
        bsAuthUsageModal.content.modalCss = "modal-info";
        bsAuthUsageModal.content.load();
    };
    AuthorizationsComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-authorizations',
            template: __webpack_require__("../../../../../src/app/views/authorizations/authorizations.component.html"),
            styles: [__webpack_require__("../../../../../src/app/views/authorizations/authorizations.component.scss")],
            providers: [__WEBPACK_IMPORTED_MODULE_2__shared_datatable_data_table_service__["a" /* DataTableService */]]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__authorizations_service__["a" /* AuthorizationsService */],
            __WEBPACK_IMPORTED_MODULE_4__shared_utils_service__["a" /* UtilityService */],
            __WEBPACK_IMPORTED_MODULE_2__shared_datatable_data_table_service__["a" /* DataTableService */],
            __WEBPACK_IMPORTED_MODULE_5_ngx_bootstrap__["a" /* BsModalService */]])
    ], AuthorizationsComponent);
    return AuthorizationsComponent;
}());



/***/ }),

/***/ "../../../../../src/app/views/authorizations/authorizations.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthorizationsModule", function() { return AuthorizationsModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ngx_bootstrap__ = __webpack_require__("../../../../ngx-bootstrap/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__authorizations_routing__ = __webpack_require__("../../../../../src/app/views/authorizations/authorizations.routing.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_shared_module__ = __webpack_require__("../../../../../src/app/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__authorizations_component__ = __webpack_require__("../../../../../src/app/views/authorizations/authorizations.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__shared_modals__ = __webpack_require__("../../../../../src/app/shared/modals/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__authorizations_service__ = __webpack_require__("../../../../../src/app/views/authorizations/authorizations.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__create_auth_modal_create_auth_modal_component__ = __webpack_require__("../../../../../src/app/views/authorizations/create-auth-modal/create-auth-modal.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__view_auth_usage_modal_view_auth_usage_modal_component__ = __webpack_require__("../../../../../src/app/views/authorizations/view-auth-usage-modal/view-auth-usage-modal.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};











var AuthorizationsModule = /** @class */ (function () {
    function AuthorizationsModule() {
    }
    AuthorizationsModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_9__angular_forms__["d" /* FormsModule */],
                __WEBPACK_IMPORTED_MODULE_2_ngx_bootstrap__["b" /* ModalModule */].forRoot(),
                __WEBPACK_IMPORTED_MODULE_3__authorizations_routing__["a" /* AuthorizationsRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_4__shared_shared_module__["a" /* SharedModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_5__authorizations_component__["a" /* AuthorizationsComponent */],
                __WEBPACK_IMPORTED_MODULE_8__create_auth_modal_create_auth_modal_component__["a" /* CreateAuthModalComponent */],
                __WEBPACK_IMPORTED_MODULE_10__view_auth_usage_modal_view_auth_usage_modal_component__["a" /* ViewAuthUsageModalComponent */]
            ],
            entryComponents: [
                __WEBPACK_IMPORTED_MODULE_6__shared_modals__["b" /* GenericModalComponent */],
                __WEBPACK_IMPORTED_MODULE_8__create_auth_modal_create_auth_modal_component__["a" /* CreateAuthModalComponent */],
                __WEBPACK_IMPORTED_MODULE_10__view_auth_usage_modal_view_auth_usage_modal_component__["a" /* ViewAuthUsageModalComponent */],
                __WEBPACK_IMPORTED_MODULE_6__shared_modals__["a" /* ConfirmModalComponent */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_7__authorizations_service__["a" /* AuthorizationsService */]
            ]
        })
    ], AuthorizationsModule);
    return AuthorizationsModule;
}());



/***/ }),

/***/ "../../../../../src/app/views/authorizations/authorizations.routing.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AuthorizationsRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__authorizations_component__ = __webpack_require__("../../../../../src/app/views/authorizations/authorizations.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__authorizations_component__["a" /* AuthorizationsComponent */],
        data: {
            title: 'Authorizations'
        }
    }
];
var AuthorizationsRoutingModule = /** @class */ (function () {
    function AuthorizationsRoutingModule() {
    }
    AuthorizationsRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["d" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["d" /* RouterModule */]]
        })
    ], AuthorizationsRoutingModule);
    return AuthorizationsRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/views/authorizations/authorizations.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AuthorizationsService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("../../../common/esm5/http.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var AuthorizationsService = /** @class */ (function () {
    function AuthorizationsService(httpClient) {
        this.httpClient = httpClient;
    }
    /**
     * Get paged authorizations
     * @param {Page} params Pagination and filters parameters
     * @returns {Observable<PagedData<any>>}
     */
    AuthorizationsService.prototype.getAuthorizationsPaged = function (params) {
        // Combine query
        var url = "/api/v1/authorization/all?pageNumber=" + params.pageNumber +
            ("&size=" + params.size);
        // Send filters as json stringify object
        if (params.filters && params.filters.length > 0) {
            url += "&filters=" + JSON.stringify(params.filters);
        }
        return this.httpClient.get(url);
    };
    /**
     *
     * @param {number} id
     * @returns {Observable<any>}
     */
    AuthorizationsService.prototype.delete = function (id) {
        return this.httpClient.delete("/api/v1/authorization?id=" + id);
    };
    /**
     *
     * @param authInsertCommand
     * @returns {Observable<any>}
     */
    AuthorizationsService.prototype.create = function (authInsertCommand) {
        return this.httpClient.post('/api/v1/authorization', authInsertCommand);
    };
    /**
     * Return a list of users and roles that use the authorization
     * @param {number} id
     * @returns {Observable<any>}
     */
    AuthorizationsService.prototype.getUsage = function (id) {
        return this.httpClient.get("/api/v1/authorization/usage?id=" + id);
    };
    AuthorizationsService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["b" /* HttpClient */]])
    ], AuthorizationsService);
    return AuthorizationsService;
}());



/***/ }),

/***/ "../../../../../src/app/views/authorizations/create-auth-modal/create-auth-modal.component.html":
/***/ (function(module, exports) {

module.exports = "<div [ngClass]=\"modalClass\">\n  <div class=\"modal-content\">\n    <div class=\"modal-header\">\n      <h4 class=\"modal-title\">{{modalTitle}}</h4>\n      <button type=\"button\" class=\"close\" (click)=\"bsModalRef.hide()\" aria-label=\"Close\">\n        <span aria-hidden=\"true\">&times;</span>\n      </button>\n    </div>\n    <div class=\"modal-body\">\n      <div class=\"form-group\">\n        <label>Name: </label>\n        <input type=\"text\" class=\"form-control\" [(ngModel)]=\"authorizationName\">\n      </div>\n    </div>\n    <div class=\"modal-footer\">\n      <button type=\"button\"\n              class=\"btn\"\n              [ngClass]=\"{'btn-default': authorizationName.match(pattern) === null, 'btn-primary' : authorizationName.match(pattern) !== null}\"\n              (click)=\"submit()\"\n              [disabled]=\"authorizationName.match(pattern) === null\">\n        Create\n      </button>\n      <button type=\"button\" class=\"btn btn-secondary\" (click)=\"bsModalRef.hide()\">Cancel</button>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "../../../../../src/app/views/authorizations/create-auth-modal/create-auth-modal.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/views/authorizations/create-auth-modal/create-auth-modal.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CreateAuthModalComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_modals__ = __webpack_require__("../../../../../src/app/shared/modals/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ngx_bootstrap_modal__ = __webpack_require__("../../../../ngx-bootstrap/modal/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_rxjs_Subject__ = __webpack_require__("../../../../rxjs/_esm5/Subject.js");
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var CreateAuthModalComponent = /** @class */ (function (_super) {
    __extends(CreateAuthModalComponent, _super);
    function CreateAuthModalComponent(bsModalRef) {
        var _this = _super.call(this, bsModalRef) || this;
        _this.bsModalRef = bsModalRef;
        _this.onCreate = new __WEBPACK_IMPORTED_MODULE_3_rxjs_Subject__["a" /* Subject */]();
        _this.authorizationName = '';
        /**
         * A valid authorization name is 3 to 12 letters length
         * @type {string}
         */
        _this.pattern = "[a-zA-Z]{3,12}";
        return _this;
    }
    CreateAuthModalComponent.prototype.submit = function () {
        this.onCreate.next(this.authorizationName);
    };
    CreateAuthModalComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-create-auth-modal',
            template: __webpack_require__("../../../../../src/app/views/authorizations/create-auth-modal/create-auth-modal.component.html"),
            styles: [__webpack_require__("../../../../../src/app/views/authorizations/create-auth-modal/create-auth-modal.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2_ngx_bootstrap_modal__["a" /* BsModalRef */]])
    ], CreateAuthModalComponent);
    return CreateAuthModalComponent;
}(__WEBPACK_IMPORTED_MODULE_1__shared_modals__["b" /* GenericModalComponent */]));



/***/ }),

/***/ "../../../../../src/app/views/authorizations/view-auth-usage-modal/view-auth-usage-modal.component.html":
/***/ (function(module, exports) {

module.exports = "<div [ngClass]=\"modalClass\">\n  <div class=\"modal-content\">\n    <div class=\"modal-header\">\n      <h4 class=\"modal-title\">{{modalTitle}}</h4>\n      <button type=\"button\" class=\"close\" (click)=\"bsModalRef.hide()\" aria-label=\"Close\">\n        <span aria-hidden=\"true\">&times;</span>\n      </button>\n    </div>\n    <div class=\"modal-body\">\n      <div class=\"row\">\n        <div style=\"max-height: 320px; overflow-y: scroll\" class=\"col-sm-12\">\n          <label>Users: </label>\n          <div *ngFor=\"let user of users\" class=\"row\">\n            <div class=\"col-sm-12\">\n              <div class=\"form-group\">\n                <input class=\"form-control\" type=\"text\" readonly [value]=\"user\">\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n      <div class=\"row\">\n        <div style=\"max-height: 320px; overflow-y: scroll\" class=\"col-sm-12\">\n          <label>Roles: </label>\n          <div *ngFor=\"let role of roles\" class=\"row\">\n            <div class=\"col-sm-12\">\n              <div class=\"form-group\">\n                <input class=\"form-control\" type=\"text\" readonly [value]=\"role\">\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n    <div class=\"modal-footer\">\n      <button type=\"button\" class=\"btn btn-secondary\" (click)=\"bsModalRef.hide()\">Close</button>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "../../../../../src/app/views/authorizations/view-auth-usage-modal/view-auth-usage-modal.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/views/authorizations/view-auth-usage-modal/view-auth-usage-modal.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ViewAuthUsageModalComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_modals__ = __webpack_require__("../../../../../src/app/shared/modals/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ngx_bootstrap_modal__ = __webpack_require__("../../../../ngx-bootstrap/modal/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__authorizations_service__ = __webpack_require__("../../../../../src/app/views/authorizations/authorizations.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_utils_service__ = __webpack_require__("../../../../../src/app/shared/utils.service.ts");
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var ViewAuthUsageModalComponent = /** @class */ (function (_super) {
    __extends(ViewAuthUsageModalComponent, _super);
    function ViewAuthUsageModalComponent(bsModalRef, authService, utils) {
        var _this = _super.call(this, bsModalRef) || this;
        _this.bsModalRef = bsModalRef;
        _this.authService = authService;
        _this.utils = utils;
        return _this;
    }
    ViewAuthUsageModalComponent.prototype.load = function () {
        var _this = this;
        this.authService.getUsage(this.authId).subscribe(function (results) {
            _this.users = results.users;
            _this.roles = results.roles;
        }, function (error) { return _this.utils.handleHttpError(error); });
    };
    ViewAuthUsageModalComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-view-auth-usage-modal',
            template: __webpack_require__("../../../../../src/app/views/authorizations/view-auth-usage-modal/view-auth-usage-modal.component.html"),
            styles: [__webpack_require__("../../../../../src/app/views/authorizations/view-auth-usage-modal/view-auth-usage-modal.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2_ngx_bootstrap_modal__["a" /* BsModalRef */],
            __WEBPACK_IMPORTED_MODULE_3__authorizations_service__["a" /* AuthorizationsService */],
            __WEBPACK_IMPORTED_MODULE_4__shared_utils_service__["a" /* UtilityService */]])
    ], ViewAuthUsageModalComponent);
    return ViewAuthUsageModalComponent;
}(__WEBPACK_IMPORTED_MODULE_1__shared_modals__["b" /* GenericModalComponent */]));



/***/ })

});
//# sourceMappingURL=authorizations.module.chunk.js.map