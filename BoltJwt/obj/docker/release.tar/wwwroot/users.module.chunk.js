webpackJsonp(["users.module"],{

/***/ "../../../../../src/app/views/users/UserDto.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UserDto; });
var UserDto = /** @class */ (function () {
    function UserDto() {
    }
    return UserDto;
}());



/***/ }),

/***/ "../../../../../src/app/views/users/create-user-modal/create-user-modal.component.html":
/***/ (function(module, exports) {

module.exports = "<p>\n  create-user-modal works!\n</p>\n"

/***/ }),

/***/ "../../../../../src/app/views/users/create-user-modal/create-user-modal.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/views/users/create-user-modal/create-user-modal.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CreateUserModalComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_modals__ = __webpack_require__("../../../../../src/app/shared/modals/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_ngx_bootstrap_modal__ = __webpack_require__("../../../../ngx-bootstrap/modal/index.js");
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var CreateUserModalComponent = /** @class */ (function (_super) {
    __extends(CreateUserModalComponent, _super);
    function CreateUserModalComponent(bsModalRef) {
        var _this = _super.call(this, bsModalRef) || this;
        _this.bsModalRef = bsModalRef;
        return _this;
    }
    CreateUserModalComponent.prototype.ngOnInit = function () {
    };
    CreateUserModalComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-create-user-modal',
            template: __webpack_require__("../../../../../src/app/views/users/create-user-modal/create-user-modal.component.html"),
            styles: [__webpack_require__("../../../../../src/app/views/users/create-user-modal/create-user-modal.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2_ngx_bootstrap_modal__["a" /* BsModalRef */]])
    ], CreateUserModalComponent);
    return CreateUserModalComponent;
}(__WEBPACK_IMPORTED_MODULE_1__shared_modals__["b" /* GenericModalComponent */]));



/***/ }),

/***/ "../../../../../src/app/views/users/user-details/user-details.component.html":
/***/ (function(module, exports) {

module.exports = "<form [formGroup]=\"form\" novalidate (ngSubmit)=\"saveUserDetails()\">\n  <div class=\"card\">\n    <div class=\"card-header\">\n      <strong>User</strong>\n      <small>Details</small>\n      <button type=\"button\" class=\"btn btn-sm btn-danger pull-right\" (click)=\"delete()\">Delete</button>\n    </div>\n    <div class=\"card-body\">\n      <div class=\"row\">\n        <div class=\"col-sm-6\">\n          <div class=\"form-group\">\n            <label>Name</label>\n            <input type=\"text\" class=\"form-control\" formControlName=\"name\">\n          </div>\n          <span style=\"color: red\" *ngIf=\"formErrors.name\">{{formErrors.name}}</span>\n        </div>\n        <div class=\"col-sm-6\">\n          <div class=\"form-group\">\n            <label>Surname</label>\n            <input type=\"text\" class=\"form-control\" formControlName=\"surname\">\n          </div>\n          <span style=\"color: red\" *ngIf=\"formErrors.surname\">{{formErrors.surname}}</span>\n        </div>\n      </div>\n      <div class=\"row\">\n        <div class=\"col-sm-6\">\n          <div class=\"form-group\">\n            <label>Email</label>\n            <input type=\"text\" readonly class=\"form-control\" [value]=\"user.Email\">\n          </div>\n        </div>\n        <div class=\"col-sm-6\">\n          <div class=\"form-group\">\n            <label>Username</label>\n            <input type=\"text\" class=\"form-control\" formControlName=\"username\">\n          </div>\n          <span style=\"color: red\" *ngIf=\"formErrors.username\">{{formErrors.username}}</span>\n        </div>\n      </div>\n    </div>\n    <div class=\"card-footer\">\n      <button [disabled]=\"form.invalid || !form.dirty\"\n              type=\"submit\"\n              [ngClass]=\"{'btn-default': form.invalid || !form.dirty, 'btn-primary' : !form.invalid && form.dirty}\"\n              class=\"btn btn-sm\">\n        <i class=\"fa fa-dot-circle-o\"></i> Save\n      </button>\n    </div>\n  </div>\n</form>\n"

/***/ }),

/***/ "../../../../../src/app/views/users/user-details/user-details.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/views/users/user-details/user-details.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UserDetailsComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_base_reactiveForm_component__ = __webpack_require__("../../../../../src/app/shared/base/reactiveForm.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__UserDto__ = __webpack_require__("../../../../../src/app/views/users/UserDto.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__users_service__ = __webpack_require__("../../../../../src/app/views/users/users.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_ngx_bootstrap__ = __webpack_require__("../../../../ngx-bootstrap/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__shared_utils_service__ = __webpack_require__("../../../../../src/app/shared/utils.service.ts");
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var UserDetailsComponent = /** @class */ (function (_super) {
    __extends(UserDetailsComponent, _super);
    function UserDetailsComponent(formBuilder, userService, modalService, utils) {
        var _this = _super.call(this) || this;
        _this.formBuilder = formBuilder;
        _this.userService = userService;
        _this.modalService = modalService;
        _this.utils = utils;
        /**
         * Edited user data
         * @type {EventEmitter<any>}
         */
        _this.editedUserInfo = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        /**
         * Deleted used
         * @type {EventEmitter<number>} User id
         */
        _this.deletedUser = new __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"]();
        _this.formErrors = {
            'name': '',
            'surname': '',
            'username': ''
        };
        _this.validationMessages = {
            'name': {
                'required': 'Required'
            },
            'surname': {
                'required': 'Required'
            },
            'username': {
                'required': 'Required'
            }
        };
        _this.userFormModel = new __WEBPACK_IMPORTED_MODULE_3__UserDto__["a" /* UserDto */]();
        _this.form = _this.formBuilder.group({
            'name': [
                _this.userFormModel.Name,
                __WEBPACK_IMPORTED_MODULE_1__angular_forms__["h" /* Validators */].required
            ],
            'surname': [
                _this.userFormModel.Surname,
                __WEBPACK_IMPORTED_MODULE_1__angular_forms__["h" /* Validators */].required
            ],
            'username': [
                _this.userFormModel.Username,
                __WEBPACK_IMPORTED_MODULE_1__angular_forms__["h" /* Validators */].required
            ]
        });
        // Trigger validation on form data change
        _this.form.valueChanges.subscribe(function (data) {
            _this.onDataChanged(data);
        });
        _this.onDataChanged();
        return _this;
    }
    /**
     * Save user details
     */
    UserDetailsComponent.prototype.saveUserDetails = function () {
        var _this = this;
        var formValue = this.form.value;
        var editCommand = {
            Id: this.user.Id,
            Name: formValue.name,
            Surname: formValue.surname,
            Username: formValue.username
        };
        this.userService.edit(editCommand).subscribe(function (response) {
            _this.editedUserInfo.emit(response.result);
        }, function (errorResponse) { return _this.utils.handleHttpError(errorResponse); });
    };
    /**
     * Delete the selected user
     */
    UserDetailsComponent.prototype.delete = function () {
        var deleteUserCallback = function () {
            var _this = this;
            this.userService.delete(this.user.Id).subscribe(function () {
                _this.deletedUser.emit();
            }, function (errorResponse) { return _this.utils.handleHttpError(errorResponse); });
        }
            .bind(this);
        // Call the delete service after confirmation
        this.utils.openConfirmModal("Delete confirmation", "Are you sure to delete the user with id: " + this.user.Id + "?", "modal-warning", deleteUserCallback);
    };
    UserDetailsComponent.prototype.ngOnInit = function () { };
    /**
     * Update the form values on parent component selection changed
     * @param {SimpleChanges} changes
     */
    UserDetailsComponent.prototype.ngOnChanges = function (changes) {
        this.resetForm();
    };
    UserDetailsComponent.prototype.resetForm = function () {
        this.form.reset({
            surname: this.user.Surname,
            name: this.user.Name,
            username: this.user.Username
        });
    };
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Input"])('user'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_3__UserDto__["a" /* UserDto */])
    ], UserDetailsComponent.prototype, "user", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])('editedUserInfo'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"])
    ], UserDetailsComponent.prototype, "editedUserInfo", void 0);
    __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Output"])('deletedUser'),
        __metadata("design:type", __WEBPACK_IMPORTED_MODULE_0__angular_core__["EventEmitter"])
    ], UserDetailsComponent.prototype, "deletedUser", void 0);
    UserDetailsComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-user-details',
            template: __webpack_require__("../../../../../src/app/views/users/user-details/user-details.component.html"),
            styles: [__webpack_require__("../../../../../src/app/views/users/user-details/user-details.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_forms__["a" /* FormBuilder */],
            __WEBPACK_IMPORTED_MODULE_4__users_service__["a" /* UsersService */],
            __WEBPACK_IMPORTED_MODULE_5_ngx_bootstrap__["a" /* BsModalService */],
            __WEBPACK_IMPORTED_MODULE_6__shared_utils_service__["a" /* UtilityService */]])
    ], UserDetailsComponent);
    return UserDetailsComponent;
}(__WEBPACK_IMPORTED_MODULE_2__shared_base_reactiveForm_component__["a" /* ReactiveFormComponent */]));



/***/ }),

/***/ "../../../../../src/app/views/users/users.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"animated fadeIn\">\n  <div class=\"row\">\n    <div class=\"col-sm-12\">\n      <div class=\"card\">\n        <div class=\"card-header\">\n          <a (click)=\"toggleAccordion()\">Filters</a>\n        </div>\n        <div *ngIf=\"filtersAccordionOpened\">\n          <app-data-table-filters\n            [filters]=\"filters\">\n          </app-data-table-filters>\n        </div>\n      </div>\n    </div>\n  </div>\n  <div class=\"row\" style=\"margin-bottom: 25px;\">\n    <div class=\"col-sm-12\">\n      <app-data-table\n        [pageSize]=\"8\"\n        [columnNames]=\"columnNames\"\n        [getData]=\"getDataFunc\"\n        [select]=\"onSelectFunc\">\n      </app-data-table>\n    </div>\n  </div>\n  <div class=\"row\" *ngIf=\"selectedUser\">\n    <div class=\"col-sm-6\">\n      <app-user-details\n        [user]=\"selectedUser\"\n        (editedUserInfo)=\"onUserEdit()\"\n        (deletedUser)=\"onUserDelete()\">\n      </app-user-details>\n    </div>\n    <div class=\"col-sm-6\">\n      <div class=\"animated fadeIn\">\n        <app-authorizations-manager\n          [entity]=\"userEntity\"\n          [entityData]=\"selectedUser\">\n        </app-authorizations-manager>\n      </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "../../../../../src/app/views/users/users.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".card-header a {\n  color: #5b06f6;\n  cursor: pointer; }\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/views/users/users.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UsersComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__users_service__ = __webpack_require__("../../../../../src/app/views/users/users.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__UserDto__ = __webpack_require__("../../../../../src/app/views/users/UserDto.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_datatable_data_table_service__ = __webpack_require__("../../../../../src/app/shared/datatable/data-table.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_common__ = __webpack_require__("../../../../../src/app/shared/common.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var UsersComponent = /** @class */ (function () {
    function UsersComponent(usersService, dataTableService) {
        this.usersService = usersService;
        this.dataTableService = dataTableService;
        this.columnNames = [
            { name: 'Name' },
            { name: 'Surname' },
            { name: 'Username' },
            { name: 'Email' }
        ];
        /**
         * Filters object for data table component
         * @type {any[]}
         */
        this.filters = [
            { label: 'Name', type: 'string', name: 'name', cssClass: 'col-sm-3' },
            { label: 'Surname', type: 'string', name: 'surname', cssClass: 'col-sm-3' },
            { label: 'Username', type: 'string', name: 'username', cssClass: 'col-sm-3' },
            { label: 'Email', type: 'string', name: 'email', cssClass: 'col-sm-3' }
        ];
        this.filtersAccordionOpened = false;
        /**
         * Type entity
         */
        this.userEntity = __WEBPACK_IMPORTED_MODULE_4__shared_common__["a" /* AppEntity */].User;
    }
    UsersComponent.prototype.ngOnInit = function () {
        // Bind
        this.getDataFunc = this.getData.bind(this);
        this.onSelectFunc = this.onSelect.bind(this);
    };
    /**
     * The service callback
     * @param params
     * @returns {Observable<PagedData<any>>}
     */
    UsersComponent.prototype.getData = function (params) {
        this.selectedUser = null;
        return this.usersService.getUsersPaged(params);
    };
    /**
     * User selection handler
     * Copy the selected user into a local dto
     * @param {any} selected
     */
    UsersComponent.prototype.onSelect = function (_a) {
        var selected = _a.selected;
        var selectedUser = selected[0];
        this.selectedUser = new __WEBPACK_IMPORTED_MODULE_2__UserDto__["a" /* UserDto */]();
        this.selectedUser.Id = selectedUser.id;
        this.selectedUser.Username = selectedUser.username;
        this.selectedUser.Name = selectedUser.name;
        this.selectedUser.Surname = selectedUser.surname;
        this.selectedUser.Email = selectedUser.email;
    };
    /**
     * Update the table after a edit
     */
    UsersComponent.prototype.onUserEdit = function () {
        this.dataTableService.invokeRowEdit();
    };
    /**
     * Update the table after a user deletion
     */
    UsersComponent.prototype.onUserDelete = function () {
        this.dataTableService.invokeRowDelete();
    };
    /**
     * Open/Close filters accordion
     */
    UsersComponent.prototype.toggleAccordion = function () {
        this.filtersAccordionOpened = !this.filtersAccordionOpened;
    };
    UsersComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            template: __webpack_require__("../../../../../src/app/views/users/users.component.html"),
            styles: [__webpack_require__("../../../../../src/app/views/users/users.component.scss")],
            // Provide the data table service for this component and his children
            providers: [__WEBPACK_IMPORTED_MODULE_3__shared_datatable_data_table_service__["a" /* DataTableService */]]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__users_service__["a" /* UsersService */],
            __WEBPACK_IMPORTED_MODULE_3__shared_datatable_data_table_service__["a" /* DataTableService */]])
    ], UsersComponent);
    return UsersComponent;
}());



/***/ }),

/***/ "../../../../../src/app/views/users/users.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsersModule", function() { return UsersModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap__ = __webpack_require__("../../../../ngx-bootstrap/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_modals__ = __webpack_require__("../../../../../src/app/shared/modals/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__shared_shared_module__ = __webpack_require__("../../../../../src/app/shared/shared.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__users_routing__ = __webpack_require__("../../../../../src/app/views/users/users.routing.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__users_service__ = __webpack_require__("../../../../../src/app/views/users/users.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__users_component__ = __webpack_require__("../../../../../src/app/views/users/users.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__user_details_user_details_component__ = __webpack_require__("../../../../../src/app/views/users/user-details/user-details.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__create_user_modal_create_user_modal_component__ = __webpack_require__("../../../../../src/app/views/users/create-user-modal/create-user-modal.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};











var UsersModule = /** @class */ (function () {
    function UsersModule() {
    }
    UsersModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_2__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_1__angular_forms__["g" /* ReactiveFormsModule */],
                __WEBPACK_IMPORTED_MODULE_3_ngx_bootstrap__["b" /* ModalModule */].forRoot(),
                __WEBPACK_IMPORTED_MODULE_6__users_routing__["a" /* UsersRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_5__shared_shared_module__["a" /* SharedModule */]
            ],
            declarations: [
                __WEBPACK_IMPORTED_MODULE_8__users_component__["a" /* UsersComponent */],
                __WEBPACK_IMPORTED_MODULE_9__user_details_user_details_component__["a" /* UserDetailsComponent */],
                __WEBPACK_IMPORTED_MODULE_10__create_user_modal_create_user_modal_component__["a" /* CreateUserModalComponent */]
            ],
            entryComponents: [
                __WEBPACK_IMPORTED_MODULE_4__shared_modals__["b" /* GenericModalComponent */],
                __WEBPACK_IMPORTED_MODULE_4__shared_modals__["a" /* ConfirmModalComponent */]
            ],
            providers: [
                __WEBPACK_IMPORTED_MODULE_7__users_service__["a" /* UsersService */]
            ]
        })
    ], UsersModule);
    return UsersModule;
}());



/***/ }),

/***/ "../../../../../src/app/views/users/users.routing.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UsersRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__users_component__ = __webpack_require__("../../../../../src/app/views/users/users.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__users_component__["a" /* UsersComponent */],
        data: {
            title: 'Users'
        }
    }
];
var UsersRoutingModule = /** @class */ (function () {
    function UsersRoutingModule() {
    }
    UsersRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["d" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["d" /* RouterModule */]]
        })
    ], UsersRoutingModule);
    return UsersRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/views/users/users.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UsersService; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common_http__ = __webpack_require__("../../../common/esm5/http.js");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var UsersService = /** @class */ (function () {
    function UsersService(httpClient) {
        this.httpClient = httpClient;
    }
    /**
     * Get paged users
     * @param {Page} params Pagination and filters parameters
     * @returns {Observable<PagedData<any>>}
     */
    UsersService.prototype.getUsersPaged = function (params) {
        // Combine query
        var url = "/api/v1/user/all?pageNumber=" + params.pageNumber +
            ("&size=" + params.size);
        // Send filters as json stringify object
        if (params.filters && params.filters.length > 0) {
            url += "&filters=" + JSON.stringify(params.filters);
        }
        return this.httpClient.get(url);
    };
    /**
     * User edit
     * @param editCommand command
     * @returns {Observable<any>}
     */
    UsersService.prototype.edit = function (editCommand) {
        return this.httpClient.post('/api/v1/user/update', editCommand);
    };
    /**
     * Delete a user
     * @param id
     * @returns {Observable<any>}
     */
    UsersService.prototype.delete = function (id) {
        return this.httpClient.delete("/api/v1/user?id=" + id);
    };
    UsersService = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_1__angular_common_http__["b" /* HttpClient */]])
    ], UsersService);
    return UsersService;
}());



/***/ })

});
//# sourceMappingURL=users.module.chunk.js.map